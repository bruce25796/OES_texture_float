#pragma once

#using<system.dll>




namespace Create32F {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
    using namespace System::IO;

	
    using namespace System::Diagnostics;


	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	public: 

		 Bitmap^  image1;
		 Label^   Label1;
       /* byte^ imageToByteArray(System.Drawing.Image imageIn)
		{
		 MemoryStream ms = new MemoryStream();
		 imageIn.Save(ms,System.Drawing.Imaging.ImageFormat.Png);
		 return  ms.ToArray();
		}
		*/
		  void CreateMyLabel()
		   {
			  // Create an instance of a Label.
			   Label1 = gcnew Label;

			  // Set the border to a three-dimensional border.
			   Label1->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			  // Set the ImageList to use for displaying an image.
			  // Label1->ImageList = imageList1;
			  // Use the second image in imageList1.
			  // Label1->ImageIndex = 1;
			  // Align the image to the top left corner.
			   Label1->ImageAlign = ContentAlignment::TopLeft;

			  // Specify that the text can display mnemonic characters.
			   Label1->UseMnemonic = true;
			  // Set the text of the control and specify a mnemonic character.
			  // label1->Text = "First &Name:";

			  /* Set the size of the control based on the PreferredHeight and PreferredWidth values. */
			   Label1->Size = System::Drawing::Size(  Label1->PreferredWidth,  Label1->PreferredHeight );

			  //...Code to add the control to the form...
		   }

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}

	protected: 
	private: System::Windows::Forms::ToolTip^  toolTip1;
	private: System::Windows::Forms::Panel^  panel1;
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	private: System::ComponentModel::IContainer^  components;

			 //--------------
			 array<Byte>^  verifyArray;
	private: System::Windows::Forms::Button^  button2;
			 array<float>   ^image_float;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
	

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			this->toolTip1 = (gcnew System::Windows::Forms::ToolTip(this->components));
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->panel1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// panel1
			// 
			this->panel1->Controls->Add(this->button2);
			this->panel1->Location = System::Drawing::Point(3, 0);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(485, 52);
			this->panel1->TabIndex = 1;
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(9, 2);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(75, 47);
			this->button2->TabIndex = 1;
			this->button2->Text = L"button2";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// pictureBox1
			// 
			this->pictureBox1->Location = System::Drawing::Point(3, 58);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(449, 423);
			this->pictureBox1->TabIndex = 2;
			this->pictureBox1->TabStop = false;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 12);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(487, 530);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->panel1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->panel1->ResumeLayout(false);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
	private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
				 //-------------------------

				String^ fileName = "D://cubetexture16x16.png";
				CreateMyLabel();

               
					 Debug::WriteLine("test");
			

				 try
				  {

					 // Retrieve the image.
					 image1 = gcnew Bitmap(fileName,true );
					 int x;
					 int y;

					 // Loop through the images pixels to reset color.
					 Debug::WriteLine("=======================");
					 
					image_float = gcnew array<float>( image1->Height*image1->Width* 4);

					int i, j;
					

					  //----------------------
					Random^ rand = gcnew Random() ; // Guid.NewGuid().GetHashCode() );
					//Debug::WriteLine(rand->NextDouble() );
					Debug::WriteLine("image1->Width = " + image1->Width );
					Debug::WriteLine("image1->Height= " + image1->Height);

					 int dst = 0;
					 for ( y = 0; y < image1->Height; y++ )
					 {
						for ( x = 0; x < image1->Width; x++ )
						{
						   Color pixelColor = image1->GetPixel( x, y );

						   Color newColor = Color::FromArgb( pixelColor.R, pixelColor.G, pixelColor.B ); // int R, G, B [ 0, 255] (int)
						   //image1->SetPixel( x, y, newColor );
						   

						   int id =  y*image1->Width + x;
						   image_float[  id*4 + 0  ] = rand->NextDouble(); // pixelColor.R/ 255.;
						   image_float[  id*4 + 1  ] = rand->NextDouble();//0.0;
						   image_float[  id*4 + 2  ] = rand->NextDouble();//0.0;
						   image_float[  id*4 + 3  ] = rand->NextDouble(); //pixelColor.R/ 255.;
						      // Debug::WriteLine(  "[" + id  + "] gl =" +  image_float[  id  ]   + " rgb= "  + pixelColor.R + " , " +  pixelColor.G + " , " +   pixelColor.B    );

						   Debug::WriteLine(  "[" + id  + "] gl =" +   id    + " rgb= "  
											   +  image_float[  id*4 + 0  ] + " , " 
											   +  image_float[  id*4 + 1  ] + " , " 
											   +  image_float[  id*4 + 2  ] + " , " 
											   +  image_float[  id*4 + 3  ] 
									      );
						  
						}

					 }
					 Debug::WriteLine("=======================");

					 // Set the PictureBox to display the image.
					 pictureBox1->Image = image1;

					 // Display the pixel format in Label1.
					 Label1->Text = String::Format( "Pixel format: {0}", image1->PixelFormat );




				  }
				  catch ( ArgumentException^ ) 
				  {
					 MessageBox::Show( "There was an error."
					 "Check the path to the image file." );
				  }



				  try {

					FileStream^ fs = gcnew FileStream("D://cubetexture16x16_float4bytes_4Channels.bin", FileMode::Create);
                    BinaryWriter^ w = gcnew BinaryWriter(fs);
				

					for (__int64 i=0; i<image_float->Length; i++)
					{
							    
						  w->Write(image_float[i]);
				    }
					//
					w->Close();
					fs->Close();
					//
				}
				catch (Exception^ e)
				{
					Debug::WriteLine("data could not be written");
					MessageBox::Show("data could not be written");
                   
				}

				Debug::WriteLine("Done.:) ");
				 //
			 }
};
}

