﻿// TexturedQuad.js (c) 2012 matsuda and kanda
// Vertex shader program
var VSHADER_SOURCE =
  'attribute vec4 a_Position;\n' +
  'attribute vec2 a_TexCoord;\n' +
  'varying vec2 v_TexCoord;\n' +
  'void main() {\n' +
  '  gl_Position = a_Position;\n' +
  '  v_TexCoord = a_TexCoord;\n' +
  '}\n';

// Fragment shader program
var FSHADER_SOURCE =
  '#ifdef GL_ES\n' +
  'precision mediump float;\n' +
  '#endif\n' +
  'uniform sampler2D u_Sampler;\n' +
  'varying vec2 v_TexCoord;\n' +
  'void main() {\n' +
  '  gl_FragColor = texture2D(u_Sampler, v_TexCoord);\n' +
  '}\n';

//-------------------
//chrome://extensions 

function getWebGLContext( canvas )
{
    var webGLContext;
    // var canvas = document.getElementById( canvas );

    /* Context name can differ according to the browser used */
    /* Store the context name in an array and check its validity */
    var names = ["webgl", "experimental-webgl", "webkit-3d", "moz-webgl"];
    for (var i = 0; i < names.length; ++i) 
    {
        try 
        {
            webGLContext = canvas.getContext(names[i]);
        }
        catch(e)
        {

        }
        if (webGLContext) break;
    }
  		
    return webGLContext;
}


function main() {
  // Retrieve <canvas> element
  var canvas = document.getElementById('webgl');
  

  // Get the rendering context for WebGL
  
  var gl = getWebGLContext(canvas );  // var gl = getWebGLContext(canvas);
  if (!gl) {
    console.log('Failed to get the rendering context for WebGL');
    return;
  }
    //-------------------------------------------------

  if (!!gl.getExtension('OES_texture_float')) {
      console.log('OES_texture_float [YES]');
  }
  else {
      console.log('OES_texture_float [NO]');
  }

    // chrome://flags/#enable-webgl-draft-extensions
 
  if (!!gl.getExtension('OES_texture_float_linear')) {
      console.log("OES_Texture_Float_Linear [YES] ");
  }
  else {
      console.log("OES_Texture_Float_Linear [NO] ");

  }

  if (!!gl.getExtension('OES_texture_half_float'))
  {
      console.log("OES_texture_half_float [YES] ");
  }
  else
  {
      console.log("OES_texture_half_float [NO] ");
  }

  if (!!gl.getExtension('OES_texture_half_float_linear'))
  {
      console.log("OES_texture_half_float_linear [YES]");

  }
  else
  {
      console.log("OES_texture_half_float_linear [NO]");
  }

  if (!!gl.getExtension('OES_color_buffer_float'))
  {
      console.log("OES_color_buffer_float [YES]");
  }
  else
  {
      console.log("OES_color_buffer_float [NO]");
  }

 // return;
  var extensions = gl.getSupportedExtensions();
  console.log("extensions=" + extensions);

  if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) {
      console.log(" cannot render");  // cant render
  }
  else console.log(" ok to render");

  
    //--------------------------------------------------
    // Initialize shaders
  if (!initShaders(gl, VSHADER_SOURCE, FSHADER_SOURCE)) {
      console.log('Failed to intialize shaders.');
      return;
  }

    // Set the vertex information
  var n = initVertexBuffers(gl);
  if (n < 0) {
      console.log('Failed to set the vertex information');
      return;
  }

    // Specify the color for clearing <canvas>
  gl.clearColor(0.2, 0.2, 0.0, 1.0);

    // Set texture
  if (!initTextures(gl, n)) {
      console.log('Failed to intialize the texture.');
      return;
  }

   
}

function initVertexBuffers(gl) {
  var verticesTexCoords = new Float32Array([
    // Vertex coordinates, texture coordinate
    -0.5,  0.5,   0.0, 1.0,
    -0.5, -0.5,   0.0, 0.0,
     0.5,  0.5,   1.0, 1.0,
     0.5, -0.5,   1.0, 0.0,
  ]);
  var n = 4; // The number of vertices

  // Create the buffer object
  var vertexTexCoordBuffer = gl.createBuffer();
  if (!vertexTexCoordBuffer) {
    console.log('Failed to create the buffer object');
    return -1;
  }

  // Bind the buffer object to target
  gl.bindBuffer(gl.ARRAY_BUFFER, vertexTexCoordBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, verticesTexCoords, gl.STATIC_DRAW);

  var FSIZE = verticesTexCoords.BYTES_PER_ELEMENT;
  //Get the storage location of a_Position, assign and enable buffer
  var a_Position = gl.getAttribLocation(gl.program, 'a_Position');
  if (a_Position < 0) {
    console.log('Failed to get the storage location of a_Position');
    return -1;
  }
  gl.vertexAttribPointer(a_Position, 2, gl.FLOAT, false, FSIZE * 4, 0);
  gl.enableVertexAttribArray(a_Position);  // Enable the assignment of the buffer object

  // Get the storage location of a_TexCoord
  var a_TexCoord = gl.getAttribLocation(gl.program, 'a_TexCoord');
  if (a_TexCoord < 0) {
    console.log('Failed to get the storage location of a_TexCoord');
    return -1;
  }
  // Assign the buffer object to a_TexCoord variable
  gl.vertexAttribPointer(a_TexCoord, 2, gl.FLOAT, false, FSIZE * 4, FSIZE * 2);
  gl.enableVertexAttribArray(a_TexCoord);  // Enable the assignment of the buffer object

  return n;
}


var oReq;
var float32Array;
var mFloatArray;

var image;
function initTextures(gl, n) {
  var texture = gl.createTexture();   // Create a texture object
  if (!texture) {
    console.log('Failed to create the texture object');
    return false;
  }

  // Get the storage location of u_Sampler
  var u_Sampler = gl.getUniformLocation(gl.program, 'u_Sampler');
  if (!u_Sampler) {
    console.log('Failed to get the storage location of u_Sampler');
    return false;
  }

//----------------------------

/*
  var image = new Image();  // Create the image object
  if (!image) {
    console.log('Failed to create the image object');
    return false;
  }
    // Register the event handler to be called on loading an image


  image.onload = function(){ loadTexture(gl, n, texture, u_Sampler, image); };*
*/
  

  console.log("Url  =" + document.location);
  console.log("PathName  =" + window.location.pathname); // Returns path only
  console.log("url  =" + window.location.href); // Returns full URL

  var       Url = document.location;
  var PathName  = window.location.pathname;
  var url = window.location.href

  var URL_doc;
    //
  var URL_body = "cubetexture16x16_float4bytes_4Channels.bin";  
  if ( location.port)
  {	
      URL_doc = "http://localhost:" + location.port + "/" + URL_body;  
  }
  else 
  {

      URL_doc = "http://localhost/VolRenWeb/ch05/" + URL_body;   
  }
  

   console.log( " URL_doc = " + URL_doc);

   try {


       if (window.ActiveXObject) {
           try {
                oReq =  new ActiveXObject("Msxml2.XMLHTTP");
           } catch (e) {
               try {
                    oReq = new ActiveXObject("Microsoft.XMLHTTP");
               } catch (e2) {
                   return null;
               }
           }
       } else if (window.XMLHttpRequest) {
            oReq=  new XMLHttpRequest();
       } else {
            oReq = null;
       }

        // oReq.overrideMimeType("application/octet-stream"); // must

       
       oReq.open('GET', URL_doc, true);  // true, asnyc
       oReq.responseType = 'arraybuffer'; // after open ::IE11

       oReq.onreadystatechange = function () {
           if (oReq.readyState == 4) {
               if (oReq.status == 200) {
                   var buffer = oReq.response;
                   var float32Array = new Float32Array(buffer); 
                   //   
                   console.log(' received = array buffer ');
                   console.log('  length= ' + float32Array.length + ', byteLength=   ' + float32Array.byteLength);
                            //
                            //
                   for (var jj = 0; jj <  float32Array.length; jj+=4) {
                            //
                       console.log("[" + jj/4 + "]=" + float32Array[jj]   +   ", " + float32Array[jj+1]   +   ", "  +  float32Array[jj+2]   +   ", " +  float32Array[jj+3]    );
                    }
                   

                    
                   

                   if (texture) {
                       loadTexture(gl, n, texture, u_Sampler, float32Array);
                       // Do something with mFloatArray
                   }
                   else {
                       alert("texture not exists !! ");
                   }
                   //
               }
               else if (oReq.status == 404) {
                   console.log("   URL doesn't exist!(Server  process error )" + oReq.status);
                   alert("URL doesn't exist!(Server  process error)" + oReq.status);
               }
               else if (oReq.status == 0) {
                   console.log("UNSEND" + " /  " + "OPENED");
               }
               else
                   console.log("Status is " + oReq.status)

           }
           if (oReq.readyState == 1) {
               console.log(" reading ...");
           }
       }



       oReq.send(null);


       
   }
   catch (e) {
       //

       console.log('An error has occurred: ' + e.message);
        alert('An error has occurred: ' + e.message);
            

         
   }


  return true;
}

function loadTexture(gl, n, texture, u_Sampler, image) {

  

  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, 1); // Flip the image's y axis
  // Enable texture unit0
  gl.activeTexture(gl.TEXTURE0);
  // Bind the texture object to the target
  gl.bindTexture(gl.TEXTURE_2D, texture);

   // Set the texture image
  if (image) {
     // 
      var ext = gl.getExtension("OES_texture_float");
      var linear =  gl.getExtension("OES_texture_float_linear");


     
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 16, 16, 0, gl.RGBA, gl.Float, image);
      // When using floating-point textures, linear filtering isn't supported, only nearest filtering.
      gl.texParameterf(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameterf(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

      // WebGL: INVALID_ENUM: texImage2D: invalid type 
  }
  else
  {
      // Set the texture 

      var dat = [];
      for (i = 0; i < 32; i++) for (j = 0; j < 32; j++)
          k = i < 16 ^ j < 16 ? 255 : 0, dat.push(k, k, k);

      var view = new Uint8Array(dat);

      gl.texParameterf(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, 32, 32, 0,  gl.RGB, gl.UNSIGNED_BYTE, view);

  }
  
  // Set the texture unit 0 to the sampler
  gl.uniform1i(u_Sampler, 0);
  
  gl.clear(gl.COLOR_BUFFER_BIT);   // Clear <canvas>

  gl.drawArrays(gl.TRIANGLE_STRIP, 0, n); // Draw the rectangle
}
